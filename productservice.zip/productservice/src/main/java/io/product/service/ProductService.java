package io.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import io.product.controller.productData;
import io.product.repo.ProductRepo;

public class ProductService {
@Autowired
	ProductRepo productRepo;
	public Optional getOneProduct(String productID) {
		// TODO Auto-generated method stub
		return  productRepo.findById(productID);
	}

	public List<productData> getAllProducts() {
		// TODO Auto-generated method stub
		return (List<productData>) productRepo.findAll();
	}

	public List<productData> saveProduct(String product) {
		// TODO Auto-generated method stub
		return (List<productData>) productRepo.save(product);
	}

}
