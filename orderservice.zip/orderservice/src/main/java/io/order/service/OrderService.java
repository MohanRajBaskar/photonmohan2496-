package io.order.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import io.order.controller.orderData;
import io.order.repo.OrderRepo;

public class OrderService {

	@Autowired
	OrderRepo orderRepo;
	public Optional getOneOrder(String productID) {
		return orderRepo.findById(productID);
	}

	public List<orderData> getAllOrders() {
		
		return (List<orderData>) orderRepo.findAll();
	}

	public List<orderData> saveOrder(String Order) {
		return (List<orderData>) orderRepo.save(Order);
	}

}
