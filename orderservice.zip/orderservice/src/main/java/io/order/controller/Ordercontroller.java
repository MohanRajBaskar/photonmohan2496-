package io.order.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.order.data.OrderData;
import io.order.service.OrderService;

@RestController
public class Ordercontroller {
	
	@Autowired
	OrderData productData;
	
	@Autowired
	OrderService orderService;

	@RequestMapping
	@GetMapping("/orders")
	public List <orderData> getAllOrders () {
		return orderService.getAllOrders();
	}
	
    @GetMapping("/orders/products/{id}")
	
	public Optional getOneOrder (@PathVariable String productID) {
		return orderService.getOneOrder(productID);
	}
	
	
	@PostMapping("/orders")
	public List <orderData> saveOrder (@RequestBody String product) {
		return orderService.saveOrder(product);
	}
	

}
